%dependence between Poisson ratio nu and the quotient K/G
close all;clear;clc;

%https://github.com/matlab2tikz/matlab2tikz/tree/master/src
matlab2tikzPath = 'C:\Users\ce9477\Desktop\MatlabTikz\Matlab2Tikz';%your address of matlab2tikz
addpath(genpath(matlab2tikzPath))

%% generate figure
blue = [0/255,150/255,130/255];

quo = logspace(0,4,100);
nu = (3*quo-2)./(6*quo+2);

figure
semilogx(quo,nu, 'color', blue, 'linewidth', 1.5)
hold on; grid on;
xlabel('K/G [-]')
ylabel('nu [-]')

%% export
%return
cleanfigure()
matlab2tikz('PoissonToKG_raw.tikz', 'height','3cm', 'width','5cm')
