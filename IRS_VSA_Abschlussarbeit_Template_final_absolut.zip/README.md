# IRS-VSA-LaTeX-Vorlage-Abschlussarbeiten

Dieses Repository enthält die LaTeX-Vorlagen für Abschlussarbeiten am Institut für Regelungs- und Steuerungssysteme (IRS) in der Professur für Vernetzte Sichere Automatisierungstechnik am KIT.

Bei der Nutzung von [Overleaf](https://www.overleaf.com) kann entweder das Template als .zip entsprechend der [Anleitung](https://www.overleaf.com/learn/how-to/Uploading_a_project) in Overleaf hochgeladen werden oder es wird das öffentliche Template genutzt.